<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\WebAuthnCredential;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class WebAuthnController extends Controller
{
    /**
     * Generate registration options for WebAuthn
     * Called when user wants to register a biometric credential
     */
    public function registerOptions(Request $request)
    {
        try {
            $user = $request->user();

            // Generate a random challenge (must be stored in session/cache for verification)
            $challenge = Str::random(32);

            // Store challenge in session for later verification
            $request->session()->put('webauthn_challenge', $challenge);
            $request->session()->put('webauthn_user_id', $user->id);

            // Get existing credentials to exclude them
            $excludeCredentials = $user->webauthnCredentials()
                ->get(['credential_id'])
                ->map(function ($cred) {
                    return [
                        'type' => 'public-key',
                        'id' => $cred->credential_id,
                    ];
                })
                ->toArray();

            $options = [
                'challenge' => base64_encode($challenge),
                'rp' => [
                    'name' => config('app.name', 'Flores D\' Jazmin'),
                    'id' => parse_url(config('app.url'), PHP_URL_HOST),
                ],
                'user' => [
                    'id' => base64_encode($user->id),
                    'name' => $user->email,
                    'displayName' => $user->name,
                ],
                'pubKeyCredParams' => [
                    ['type' => 'public-key', 'alg' => -7],  // ES256
                    ['type' => 'public-key', 'alg' => -257], // RS256
                ],
                'timeout' => 60000,
                'attestation' => 'none',
                'excludeCredentials' => $excludeCredentials,
                'authenticatorSelection' => [
                    'authenticatorAttachment' => 'platform', // Prefer platform authenticators (biometrics)
                    'requireResidentKey' => false,
                    'residentKey' => 'preferred',
                    'userVerification' => 'required', // Require biometric verification
                ],
            ];

            return response()->json([
                'success' => true,
                'data' => $options
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate registration options',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Verify and store the registered credential
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'credential_id' => 'required|string',
            'public_key' => 'required|string',
            'aaguid' => 'nullable|string',
            'counter' => 'required|integer',
            'device_name' => 'nullable|string|max:255',
            'device_type' => 'nullable|string|in:fingerprint,face,security_key',
            'transports' => 'nullable|array',
            'attestation_object' => 'required|string',
            'client_data_json' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation errors',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = $request->user();

            // Verify challenge
            $storedChallenge = $request->session()->get('webauthn_challenge');
            $storedUserId = $request->session()->get('webauthn_user_id');

            if (!$storedChallenge || $storedUserId != $user->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or expired challenge'
                ], 400);
            }

            // Decode and verify client data
            $clientDataJSON = base64_decode($request->client_data_json);
            $clientData = json_decode($clientDataJSON, true);

            // Verify challenge matches
            if (base64_encode($storedChallenge) !== $clientData['challenge']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Challenge mismatch'
                ], 400);
            }

            // Verify origin
            $expectedOrigin = config('app.url');
            if ($clientData['origin'] !== $expectedOrigin) {
                return response()->json([
                    'success' => false,
                    'message' => 'Origin mismatch'
                ], 400);
            }

            // Check if credential already exists
            if (WebAuthnCredential::where('credential_id', $request->credential_id)->exists()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Credential already registered'
                ], 409);
            }

            // Create credential
            $credential = WebAuthnCredential::create([
                'user_id' => $user->id,
                'credential_id' => $request->credential_id,
                'public_key' => $request->public_key,
                'aaguid' => $request->aaguid,
                'counter' => $request->counter,
                'device_name' => $request->device_name ?? 'Dispositivo Biométrico',
                'device_type' => $request->device_type ?? 'fingerprint',
                'user_agent' => $request->header('User-Agent'),
                'transports' => $request->transports,
                'is_discoverable' => $request->is_discoverable ?? false,
                'backup_eligible' => $request->backup_eligible ?? false,
                'backup_state' => $request->backup_state ?? false,
                'last_used_at' => now(),
                'last_used_ip' => $request->ip(),
                'use_count' => 0,
            ]);

            // Clear challenge from session
            $request->session()->forget(['webauthn_challenge', 'webauthn_user_id']);

            return response()->json([
                'success' => true,
                'message' => 'Biometric credential registered successfully',
                'data' => [
                    'id' => $credential->id,
                    'device_name' => $credential->device_name,
                    'device_type' => $credential->device_type_label,
                    'created_at' => $credential->created_at
                ]
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to register credential',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Generate authentication options for WebAuthn login
     */
    public function loginOptions(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|exists:users,email',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation errors',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            $user = User::where('email', $request->email)->first();

            if (!$user || !$user->is_active) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found or inactive'
                ], 404);
            }

            // Get user's credentials
            $credentials = $user->webauthnCredentials()
                ->get(['credential_id'])
                ->map(function ($cred) {
                    return [
                        'type' => 'public-key',
                        'id' => $cred->credential_id,
                    ];
                })
                ->toArray();

            if (empty($credentials)) {
                return response()->json([
                    'success' => false,
                    'message' => 'No biometric credentials found for this user',
                    'has_credentials' => false
                ], 404);
            }

            // Generate challenge
            $challenge = Str::random(32);

            // Store challenge in session
            $request->session()->put('webauthn_login_challenge', $challenge);
            $request->session()->put('webauthn_login_email', $user->email);

            $options = [
                'challenge' => base64_encode($challenge),
                'timeout' => 60000,
                'rpId' => parse_url(config('app.url'), PHP_URL_HOST),
                'allowCredentials' => $credentials,
                'userVerification' => 'required',
            ];

            return response()->json([
                'success' => true,
                'has_credentials' => true,
                'data' => $options
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to generate login options',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Verify authentication and login user
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'credential_id' => 'required|string',
            'authenticator_data' => 'required|string',
            'client_data_json' => 'required|string',
            'signature' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation errors',
                'errors' => $validator->errors()
            ], 422);
        }

        try {
            // Verify challenge
            $storedChallenge = $request->session()->get('webauthn_login_challenge');
            $storedEmail = $request->session()->get('webauthn_login_email');

            if (!$storedChallenge || !$storedEmail) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or expired challenge'
                ], 400);
            }

            // Find credential
            $credential = WebAuthnCredential::where('credential_id', $request->credential_id)->first();

            if (!$credential) {
                return response()->json([
                    'success' => false,
                    'message' => 'Credential not found'
                ], 404);
            }

            $user = $credential->user;

            if (!$user || $user->email !== $storedEmail || !$user->is_active) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found or inactive'
                ], 403);
            }

            // Decode and verify client data
            $clientDataJSON = base64_decode($request->client_data_json);
            $clientData = json_decode($clientDataJSON, true);

            // Verify challenge
            if (base64_encode($storedChallenge) !== $clientData['challenge']) {
                return response()->json([
                    'success' => false,
                    'message' => 'Challenge mismatch'
                ], 400);
            }

            // Verify origin
            $expectedOrigin = config('app.url');
            if ($clientData['origin'] !== $expectedOrigin) {
                return response()->json([
                    'success' => false,
                    'message' => 'Origin mismatch'
                ], 400);
            }

            // Decode authenticator data
            $authenticatorData = base64_decode($request->authenticator_data);

            // Extract counter from authenticator data (bytes 33-36)
            $counter = unpack('N', substr($authenticatorData, 33, 4))[1];

            // Verify counter is greater than stored counter (anti-cloning)
            if ($counter <= $credential->counter) {
                return response()->json([
                    'success' => false,
                    'message' => 'Possible cloned authenticator detected'
                ], 400);
            }

            // TODO: Verify signature using public key
            // This requires a proper cryptographic library
            // For now, we'll trust the credential based on challenge verification

            // Update credential usage
            $credential->counter = $counter;
            $credential->recordUsage($request->ip());

            // Update user last login
            $user->last_login_at = now();
            $user->save();

            // Clear challenge from session
            $request->session()->forget(['webauthn_login_challenge', 'webauthn_login_email']);

            // Revoke old tokens
            $user->tokens()->delete();

            // Create new token
            $token = $user->createToken('auth_token', ['*'], now()->addHours(8))->plainTextToken;

            return response()->json([
                'success' => true,
                'message' => 'Login successful with biometric authentication',
                'data' => [
                    'user' => $user,
                    'token' => $token,
                    'token_type' => 'Bearer',
                    'expires_at' => now()->addHours(8)->toISOString(),
                    'auth_method' => 'webauthn'
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Authentication failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * List user's registered credentials
     */
    public function listCredentials(Request $request)
    {
        try {
            $credentials = $request->user()
                ->webauthnCredentials()
                ->orderBy('last_used_at', 'desc')
                ->get()
                ->map(function ($cred) {
                    return [
                        'id' => $cred->id,
                        'device_name' => $cred->device_name,
                        'device_type' => $cred->device_type_label,
                        'is_platform' => $cred->isPlatformAuthenticator(),
                        'last_used_at' => $cred->last_used_at?->diffForHumans(),
                        'use_count' => $cred->use_count,
                        'created_at' => $cred->created_at->format('d/m/Y H:i'),
                    ];
                });

            return response()->json([
                'success' => true,
                'data' => $credentials
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to list credentials',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete a credential
     */
    public function deleteCredential(Request $request, $id)
    {
        try {
            $credential = $request->user()
                ->webauthnCredentials()
                ->findOrFail($id);

            $credential->delete();

            return response()->json([
                'success' => true,
                'message' => 'Credential deleted successfully'
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete credential',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check if user has biometric credentials
     */
    public function checkAvailability(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'available' => false,
                'message' => 'Email is required'
            ], 422);
        }

        try {
            $user = User::where('email', $request->email)->first();

            if (!$user) {
                return response()->json([
                    'success' => true,
                    'available' => false,
                    'message' => 'User not found'
                ]);
            }

            $hasCredentials = $user->webauthnCredentials()->exists();

            return response()->json([
                'success' => true,
                'available' => $hasCredentials,
                'count' => $user->webauthnCredentials()->count()
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'available' => false,
                'message' => 'Failed to check availability',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}

